import { useEffect, useRef, useCallback } from "react";

interface UseAutoScrollOptions {
  interval?: number;
  scrollAmount?: number;
  enabled?: boolean;
}

export const useAutoScroll = ({
  interval = 2000,
  scrollAmount = 300,
  enabled = true,
}: UseAutoScrollOptions = {}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const isHovering = useRef(false);

  const scroll = useCallback(() => {
    if (!containerRef.current || isHovering.current) return;
    
    const container = containerRef.current;
    const maxScroll = container.scrollWidth - container.clientWidth;
    
    if (container.scrollLeft >= maxScroll - 10) {
      // Reset to start with smooth animation
      container.scrollTo({ left: 0, behavior: "smooth" });
    } else {
      container.scrollBy({ left: scrollAmount, behavior: "smooth" });
    }
  }, [scrollAmount]);

  useEffect(() => {
    if (!enabled) return;
    
    const intervalId = setInterval(scroll, interval);
    return () => clearInterval(intervalId);
  }, [scroll, interval, enabled]);

  const handleMouseEnter = useCallback(() => {
    isHovering.current = true;
  }, []);

  const handleMouseLeave = useCallback(() => {
    isHovering.current = false;
  }, []);

  return {
    containerRef,
    handleMouseEnter,
    handleMouseLeave,
  };
};
