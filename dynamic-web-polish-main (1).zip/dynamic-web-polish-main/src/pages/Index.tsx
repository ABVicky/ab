import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Pen, Code, Layers, Calendar, Mic, Users, Lightbulb } from "lucide-react";
import { MainLayout } from "@/components/layout/MainLayout";
import { ScrollReveal, StaggerContainer, StaggerItem } from "@/components/animations/ScrollReveal";
import { HeroAnimation } from "@/components/animations/PageTransition";
import { LiftHover } from "@/components/animations/HoverEffects";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DesktopNavbar } from "@/components/layout/Navbar";

const services = [
  {
    icon: Pen,
    title: "UI & Experience Design",
    description: "I craft clean, intuitive, and purposeful interfaces where form follows function.",
    quote: "A good beginning makes a good ending.",
  },
  {
    icon: Code,
    title: "Full-Stack Web Development",
    description: "I build scalable, performance-driven web applications using modern stacks.",
    quote: "Well begun is half done.",
  },
  {
    icon: Layers,
    title: "Platform & Product Building",
    description: "From idea to execution, I create platforms that solve real problems.",
    quote: "Necessity is the mother of invention.",
  },
  {
    icon: Calendar,
    title: "Event Leadership & Management",
    description: "I have led and organized 30+ academic, technical, and cultural events.",
    quote: "Unity is strength.",
  },
  {
    icon: Mic,
    title: "Stage Hosting & Public Speaking",
    description: "A confident anchor engaging audiences with clarity and presence.",
    quote: "Words fitly spoken are like apples of gold.",
  },
  {
    icon: Users,
    title: "Mentorship & Community Building",
    description: "I mentor peers and build learning-driven communities.",
    quote: "If you want to go far, go together.",
  },
  {
    icon: Lightbulb,
    title: "Entrepreneurship & Initiative",
    description: "I take initiative and turn ideas into execution with discipline.",
    quote: "Little drops make the mighty ocean.",
  },
];

const testimonials = [
  {
    name: "Prof. Kajali Raina",
    image: "https://abvicky.github.io/Portfolio/Images/Raina_mam.jpg",
    text: "Vicky Prasad Mahato as I know him is an enterprising student of IT 3rd Year at BBIT. Vicky is passionate about whatever he does and an extremely spirited boy. He has big dreams and he loves to chase them till fulfilment. A student who has always looked back with fond gratitude and has reverence for all. However Vicky's weakness is that he cannot accept NO for an answer. It is very important to inculcate this strength of being gracious of refusals. I wish Vicky the best of life as he keeps on escalating his skills. A talented boy who wins my heart with every encounter.",
  },
  {
    name: "Prof(Dr.) M. Yusuf Alam",
    image: "https://abvicky.github.io/Portfolio/Images/Yusuf_sir.jpg",
    text: "Vicky's aim in life is to become a successful entrepreneur. Currently, he serves as the Chief Students Coordinator of the Entrepreneurship Development Cell (EDC) and the Innovation and Incubation Center (IIC) at BBIT Kolkata. Driven by a passion for learning new technologies, he also enjoys organizing both technical and non-technical events. As an achiever, Vicky is one of the founders of the Coders' Club at BBIT Kolkata. He values the importance of respecting seniors and nurturing relationships with juniors, keenly observing his surroundings, and striving to fulfill his social responsibilities.",
  },
  {
    name: "Prof(Dr.) Ashok Kr Shaw",
    image: "https://abvicky.github.io/Portfolio/Images/Ashok_Sir.png",
    text: "Vicky is a very enthusiastic student having multi facet talent and team building capabilities and team leading qualities. Whenever we have assigned any responsibility from IIC and ED Cell, he has coordinated everything so well with great sense of responsibility. Even he is a Tech enthusiast. He is also having entrepreneurial spirit and I am confident that he will be a successful entrepreneur also very soon. Vicky is obedient, sincere and he respects his teachers. I wish my Dear student Vicky every success in his life.",
  },
  {
    name: "Mr. Rocky Yadav",
    image: "https://abvicky.github.io/Portfolio/Images/Rocky_sir.png",
    text: "If it's Vicky, you are definitely relying on a person who has both leadership and managerial skills. Not only he offers an open arm for any question, he makes sure that you are provided with a solution as early as possible. Being an extrovert, he gels up pretty good with a team, and can also help the team excel if given a chance. One of his other qualities includes his eagerness to learn. This allows him to learn and stay at par with the new things. All of this along with his humble and joyful approach, he will make even the toughest and boring tasks as easy and fun.",
  },
  {
    name: "Soham Pattanayak",
    image: "https://abvicky.github.io/Portfolio/Images/Soham.jpg",
    text: "I am very lucky to have a good friend like Vicky & had the privilege of working closely with him in different fields for last several months. His dedication to excellence, unwavering work ethic, and exceptional problem-solving skills, leadership skills have consistently impressed me. He is a true friendly guy, always willing to go the extra mile to deliver outstanding results. His work really inspires me. I am confident that Vicky will excel in any endeavor he chooses to pursue. He always goes out of his ways to help as many people as possible.",
  },
  {
    name: "Jassi Prasad",
    image: "https://abvicky.in/assets/images/avatar-3.png",
    text: "Vicky is that classmate who will always spread a positive aura and motivate other fellows for a healthy competition in any field. Personally, if you ask me I love the management skill of him, the way he collabs his studies with other curriculum is always upto mark in quality and yeah with honesty of course. He is the synonym of unstoppable, like always doing and creating something new always, the curious and fearless explorer. He stays curious 24/7, as if he won't stop until he knows everything about everything. He is a full stack in real life! 🪄",
  },
  {
    name: "Laiba Sajid",
    image: "https://abvicky.github.io/Portfolio/Images/Laiba.png",
    text: "Vicky is not just a classmate but a true source of inspiration and guidance. One of the most hardworking and talented people in our batch, he has great sense of responsibility and put himself out there to use in all good aspects of curriculum. He sometimes takes up many commitments at once and that somewhere decreases his overall productivity, but after having experienced this he worked hard and made himself shine throughout. It is great to know him and his utmost dedication towards his work.",
  },
];

const stats = [
  { value: "30+", label: "Events Organized" },
  { value: "20+", label: "Programs Hosted" },
  { value: "3+", label: "Years Experience" },
  { value: "100+", label: "People Mentored" },
];

const Index = () => {
  const [selectedTestimonial, setSelectedTestimonial] = useState<typeof testimonials[0] | null>(null);
  const testimonialsRef = useRef<HTMLDivElement>(null);
  const orgsRef = useRef<HTMLDivElement>(null);
  const isTestimonialsHovering = useRef(false);
  const isOrgsHovering = useRef(false);

  // Auto-scroll for testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      if (!testimonialsRef.current || isTestimonialsHovering.current) return;
      
      const container = testimonialsRef.current;
      const maxScroll = container.scrollWidth - container.clientWidth;
      
      if (container.scrollLeft >= maxScroll - 10) {
        container.scrollTo({ left: 0, behavior: "smooth" });
      } else {
        container.scrollBy({ left: 240, behavior: "smooth" });
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);

  // Auto-scroll for organizations
  useEffect(() => {
    const interval = setInterval(() => {
      if (!orgsRef.current || isOrgsHovering.current) return;
      
      const container = orgsRef.current;
      const maxScroll = container.scrollWidth - container.clientWidth;
      
      if (container.scrollLeft >= maxScroll - 10) {
        container.scrollTo({ left: 0, behavior: "smooth" });
      } else {
        container.scrollBy({ left: 120, behavior: "smooth" });
      }
    }, 2000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <MainLayout>
      <div className="space-y-4 sm:space-y-5 md:space-y-6">
        {/* Hero Section - Article style */}
        <motion.section 
          className="card-premium p-3 sm:p-4 md:p-6 animate-fade"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Desktop Navbar */}
          <DesktopNavbar />
          
          <HeroAnimation>
            <h1 className="section-title">About me</h1>
          </HeroAnimation>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="italic text-xs sm:text-sm md:text-base mt-3 sm:mt-4 md:mt-5 mb-3 sm:mb-4 md:mb-5"
            style={{ color: 'hsl(var(--primary))' }}
          >
            "Execution turns vision into impact."
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="space-y-2 sm:space-y-3 md:space-y-4 text-xs sm:text-sm md:text-base leading-relaxed"
            style={{ color: 'hsl(var(--text-muted))' }}
          >
            <p>
              <span className="font-medium" style={{ color: 'hsl(var(--foreground))' }}>Vicky Prasad Mahato</span> is a results-driven leader with hands-on experience in management, execution, and community building. During their journey at BBIT, they have successfully organized <span className="font-medium" style={{ color: 'hsl(var(--primary))' }}>30+ events</span> and hosted <span className="font-medium" style={{ color: 'hsl(var(--primary))' }}>20+ cultural and formal programs</span>.
            </p>
            <p>
              As the <span className="font-medium" style={{ color: 'hsl(var(--foreground))' }}>Founder and Lead of the Entrepreneurship Development Cell (EDC)</span> at BBIT, Vicky has focused on fostering innovation, teamwork, and practical problem-solving. From leading large-scale initiatives like the <span className="font-medium" style={{ color: 'hsl(var(--primary))' }}>Innov8 Hackathon</span> to building <span className="font-medium" style={{ color: 'hsl(var(--primary))' }}>पढ़ाकू</span>, their work reflects consistent effort to create meaningful solutions.
            </p>
          </motion.div>

          {/* Stats Counter */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="grid grid-cols-2 md:grid-cols-4 gap-2 sm:gap-3 md:gap-4 mt-4 sm:mt-5 md:mt-6"
          >
            {stats.map((stat, index) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.6 + index * 0.1 }}
                className="text-center p-2 sm:p-3 md:p-4 rounded-lg md:rounded-xl"
                style={{ background: 'hsl(var(--secondary) / 0.5)' }}
              >
                <div className="text-lg sm:text-xl md:text-3xl lg:text-4xl font-bold text-gradient-gold mb-0.5">
                  {stat.value}
                </div>
                <div className="text-[9px] sm:text-[10px] md:text-xs lg:text-sm" style={{ color: 'hsl(var(--text-muted))' }}>
                  {stat.label}
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.section>

        {/* What I Do Section - Service cards with original style */}
        <section>
          <ScrollReveal>
            <h2 className="section-title mb-3 md:mb-5">What I Do</h2>
          </ScrollReveal>

          <StaggerContainer className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4">
            {services.map((service, index) => (
              <StaggerItem key={service.title}>
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: index * 0.05 }}
                >
                  <LiftHover>
                    <div className="service-card text-left flex items-start gap-3 md:gap-4">
                      <div className="service-card-icon flex-shrink-0">
                        <service.icon size={18} className="md:hidden" />
                        <service.icon size={20} className="hidden md:block" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-xs sm:text-sm md:text-base mb-1" style={{ color: 'hsl(var(--text-secondary))' }}>
                          {service.title}
                        </h4>
                        <p className="text-[11px] sm:text-xs md:text-sm mb-1" style={{ color: 'hsl(var(--text-muted))' }}>
                          {service.description}
                        </p>
                        <p className="text-[10px] sm:text-[11px] md:text-xs italic" style={{ color: 'hsl(var(--primary))' }}>
                          "{service.quote}"
                        </p>
                      </div>
                    </div>
                  </LiftHover>
                </motion.div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </section>

        {/* Testimonials Section - Horizontal scroll with original card style */}
        <section className="card-premium p-3 sm:p-4 md:p-6 mb-3 md:mb-4">
          <ScrollReveal>
            <h3 className="section-title mb-3 md:mb-5">Testimonials</h3>
          </ScrollReveal>

          <ScrollReveal delay={0.1}>
            <div 
              ref={testimonialsRef}
              className="flex gap-3 md:gap-4 overflow-x-auto pb-3 md:pb-4 pt-8 md:pt-10 has-scrollbar"
              onMouseEnter={() => { isTestimonialsHovering.current = true; }}
              onMouseLeave={() => { isTestimonialsHovering.current = false; }}
              onTouchStart={() => { isTestimonialsHovering.current = true; }}
              onTouchEnd={() => { isTestimonialsHovering.current = false; }}
            >
              {testimonials.map((testimonial, index) => (
                <motion.div
                  key={testimonial.name}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="min-w-[220px] sm:min-w-[260px] md:min-w-[300px] flex-shrink-0 cursor-pointer"
                  onClick={() => setSelectedTestimonial(testimonial)}
                >
                  <div className="content-card relative pt-10 md:pt-12 hover:border-primary/50 transition-colors h-full">
                    {/* Avatar positioned at top */}
                    <figure 
                      className="absolute -top-5 md:-top-6 left-3 md:left-4 rounded-[12px] md:rounded-[14px] overflow-hidden"
                      style={{ 
                        background: 'var(--bg-gradient-onyx)',
                        boxShadow: 'var(--shadow-1)'
                      }}
                    >
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-11 h-11 sm:w-12 sm:h-12 md:w-14 md:h-14 object-cover"
                        loading="lazy"
                      />
                    </figure>
                    
                    <div>
                      <h4 className="font-medium text-xs sm:text-sm mb-1.5 md:mb-2" style={{ color: 'hsl(var(--text-secondary))' }}>
                        {testimonial.name}
                      </h4>
                      <p 
                        className="text-[11px] sm:text-xs md:text-sm leading-relaxed line-clamp-4"
                        style={{ color: 'hsl(var(--text-muted))' }}
                      >
                        {testimonial.text}
                      </p>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </ScrollReveal>

          {/* Testimonial Popup Dialog - Modal style */}
          <ScrollReveal delay={0.2}>
            <Dialog open={!!selectedTestimonial} onOpenChange={() => setSelectedTestimonial(null)}>
              <DialogContent 
                className="max-w-[85vw] sm:max-w-[80vw] md:max-w-lg rounded-[12px] sm:rounded-[14px] p-3 sm:p-4 md:p-6"
                style={{ 
                  background: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  boxShadow: 'var(--shadow-5)'
                }}
              >
                <DialogHeader>
                  <div className="flex items-center gap-3 sm:gap-4">
                    {selectedTestimonial && (
                      <>
                        <figure 
                          className="rounded-[10px] sm:rounded-[12px] md:rounded-[14px] overflow-hidden flex-shrink-0"
                          style={{ 
                            background: 'var(--bg-gradient-onyx)',
                            boxShadow: 'var(--shadow-2)'
                          }}
                        >
                          <img
                            src={selectedTestimonial.image}
                            alt={selectedTestimonial.name}
                            className="w-12 h-12 sm:w-14 sm:h-14 md:w-16 md:h-16 lg:w-20 lg:h-20 object-cover"
                          />
                        </figure>
                        <DialogTitle 
                          className="text-sm sm:text-base md:text-lg font-medium"
                          style={{ color: 'hsl(var(--text-secondary))' }}
                        >
                          {selectedTestimonial.name}
                        </DialogTitle>
                      </>
                    )}
                  </div>
                </DialogHeader>
                <div className="mt-3 sm:mt-4">
                  <p 
                    className="leading-relaxed text-xs sm:text-sm md:text-base"
                    style={{ color: 'hsl(var(--text-muted))' }}
                  >
                    {selectedTestimonial?.text}
                  </p>
                </div>
              </DialogContent>
            </Dialog>
          </ScrollReveal>
        </section>

        {/* Organizations - Clients style */}
        <section className="card-premium p-4 md:p-8 mb-4">
          <ScrollReveal>
            <h3 className="section-title mb-4 md:mb-5">Organisations I've Worked With</h3>
          </ScrollReveal>

          <ScrollReveal delay={0.2}>
            <div 
              ref={orgsRef}
              className="flex gap-6 overflow-x-auto py-6 has-scrollbar"
              onMouseEnter={() => { isOrgsHovering.current = true; }}
              onMouseLeave={() => { isOrgsHovering.current = false; }}
              onTouchStart={() => { isOrgsHovering.current = true; }}
              onTouchEnd={() => { isOrgsHovering.current = false; }}
            >
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map((num) => (
                <motion.a
                  key={num}
                  href="#"
                  whileHover={{ scale: 1.05 }}
                  className="flex items-center justify-center flex-shrink-0 min-w-[calc(50%-10px)] md:min-w-[calc(25%-15px)] transition-all duration-300 group"
                >
                  <img
                    src={`https://abvicky.in/assets/images/brand_Logo/${num}.png`}
                    alt={`Organization ${num}`}
                    className="h-12 md:h-16 w-auto object-contain grayscale transition-all duration-300 group-hover:grayscale-0"
                    loading="lazy"
                  />
                </motion.a>
              ))}
            </div>
          </ScrollReveal>
        </section>
      </div>
    </MainLayout>
  );
};

export default Index;
