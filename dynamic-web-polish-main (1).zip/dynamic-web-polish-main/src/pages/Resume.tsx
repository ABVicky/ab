import { MainLayout } from "@/components/layout/MainLayout";
import { ScrollReveal, StaggerContainer, StaggerItem } from "@/components/animations/ScrollReveal";
import { motion } from "framer-motion";
import { GraduationCap, Briefcase } from "lucide-react";
import { DesktopNavbar } from "@/components/layout/Navbar";

const education = [
  {
    title: "Maulana Abul Kalam Azad University of Technology",
    period: "2021 — Continue",
    subtitle: "Bachelor of Technology in Information Technology",
    description: "Pursuing B.Tech at Budge Budge Institute of Technology, exploring cybersecurity, cloud computing, and project management. President of Coders' Club, organizing flagship events like League of Errors with 800+ participants.",
  },
  {
    title: "Higher Secondary Education",
    period: "2019 — 2021",
    subtitle: "Cathedral Mission High School",
    description: "Completed Higher Secondary with 80.2% marks, building a strong academic foundation.",
  },
  {
    title: "Secondary Education",
    period: "2019",
    subtitle: "North Kolkata Public School, Kolkata",
    description: "Completed secondary education with focus on science and mathematics.",
  },
];

const experience = [
  {
    title: "Content Writer & Academic Researcher",
    company: "TeaChief Academy",
    period: "2021 — 2022",
    quote: "Knowledge grows when research meets clarity.",
    description: "Contributed to educational content and academic research papers. Conducted in-depth research and drafted well-referenced academic documents.",
    keywords: ["Content Writing", "Academic Research", "Research Paper Writing"],
  },
  {
    title: "Business Operations & Retail Management",
    company: "Pushpa Jewellers",
    period: "2022 — 2023",
    quote: "Strong systems create sustainable businesses.",
    description: "Gained hands-on experience in inventory management, stock handling, and store operations. Generated potential business leads using Google Maps research.",
    keywords: ["Inventory Management", "Retail Operations", "Lead Generation"],
  },
  {
    title: "Business Development Counsellor",
    company: "PlanetSpark",
    period: "2023 — 2024",
    quote: "Every conversation is an opportunity to create value.",
    description: "Managed inbound and outbound calls, conducted video counselling sessions, and guided leads through the sales funnel.",
    keywords: ["Business Development", "CRM Management", "EdTech Sales"],
  },
  {
    title: "Freelance Creative Designer & Social Media Manager",
    company: "Multiple Clients",
    period: "2021 — 2024",
    quote: "Design speaks before words are read.",
    description: "Freelanced for BBIT College, BBIT Public School, and JIMSH Medical Hospital. Created social media creatives and digital assets.",
    keywords: ["Graphic Design", "Social Media Marketing", "Digital Branding"],
  },
  {
    title: "Freelance Video Editor",
    company: "RivuTalks",
    period: "2023 — 2024",
    quote: "Stories gain power when visuals meet purpose.",
    description: "Edited YouTube podcasts and online courses with focus on storytelling and brand consistency.",
    keywords: ["Video Editing", "YouTube Podcasts", "Media Production"],
  },
];

const skills = [
  { name: "Java", percentage: 65 },
  { name: "Frontend Development", percentage: 80 },
  { name: "Web Design", percentage: 80 },
  { name: "Graphic Design", percentage: 60 },
  { name: "Branding", percentage: 90 },
  { name: "WordPress", percentage: 60 },
];

const Resume = () => {
  return (
    <MainLayout>
      <div className="space-y-4 sm:space-y-5 md:space-y-6">
        {/* Education Section */}
        <motion.section 
          className="card-premium p-3 sm:p-4 md:p-6 animate-fade"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Desktop Navbar */}
          <DesktopNavbar />
          
          <ScrollReveal>
            <h1 className="section-title mb-4 sm:mb-6 md:mb-8">Resume</h1>
          </ScrollReveal>
          
          {/* Education Timeline */}
          <div className="mb-5 sm:mb-6 md:mb-8">
            <ScrollReveal>
              <div className="flex items-center gap-2.5 sm:gap-3 md:gap-4 mb-4 sm:mb-5 md:mb-6">
                <div className="icon-box w-9 h-9 sm:w-10 sm:h-10 md:w-12 md:h-12">
                  <GraduationCap size={16} className="sm:hidden" />
                  <GraduationCap size={18} className="hidden sm:block md:hidden" />
                  <GraduationCap size={20} className="hidden md:block" />
                </div>
                <h3 className="text-sm sm:text-base md:text-lg font-medium" style={{ color: 'hsl(var(--text-secondary))' }}>
                  Education
                </h3>
              </div>
            </ScrollReveal>

            <div className="space-y-0">
              {education.map((item, index) => (
                <ScrollReveal key={item.title} delay={index * 0.1}>
                  <div className="timeline-item">
                    <h4 
                      className="text-xs sm:text-sm font-normal leading-tight mb-1 sm:mb-1.5"
                      style={{ color: 'hsl(var(--text-secondary))' }}
                    >
                      {item.title}
                    </h4>
                    <span 
                      className="text-xs sm:text-sm font-normal block mb-1 sm:mb-1.5"
                      style={{ color: 'hsl(var(--gold-dark))' }}
                    >
                      {item.period}
                    </span>
                    <p 
                      className="text-[11px] sm:text-xs md:text-sm font-light leading-relaxed text-justify"
                      style={{ color: 'hsl(var(--text-muted))' }}
                    >
                      {item.description}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>

          {/* Experience Timeline */}
          <div>
            <ScrollReveal>
              <div className="flex items-center gap-2.5 sm:gap-3 md:gap-4 mb-4 sm:mb-5 md:mb-6">
                <div className="icon-box w-9 h-9 sm:w-10 sm:h-10 md:w-12 md:h-12">
                  <Briefcase size={16} className="sm:hidden" />
                  <Briefcase size={18} className="hidden sm:block md:hidden" />
                  <Briefcase size={20} className="hidden md:block" />
                </div>
                <h3 className="text-sm sm:text-base md:text-lg font-medium" style={{ color: 'hsl(var(--text-secondary))' }}>
                  Experience
                </h3>
              </div>
            </ScrollReveal>

            <div className="space-y-0">
              {experience.map((item, index) => (
                <ScrollReveal key={item.title} delay={index * 0.1}>
                  <div className="timeline-item">
                    <h4 
                      className="text-xs sm:text-sm font-normal leading-tight mb-1"
                      style={{ color: 'hsl(var(--text-secondary))' }}
                    >
                      {item.title}
                    </h4>
                    <span 
                      className="text-xs sm:text-sm font-normal block mb-1 sm:mb-1.5"
                      style={{ color: 'hsl(var(--gold-dark))' }}
                    >
                      {item.period}
                    </span>
                    <p 
                      className="text-[11px] sm:text-xs md:text-sm font-light leading-relaxed text-justify"
                      style={{ color: 'hsl(var(--text-muted))' }}
                    >
                      {item.description}
                    </p>
                  </div>
                </ScrollReveal>
              ))}
            </div>
          </div>
        </motion.section>

        {/* Skills Section */}
        <motion.section 
          className="card-premium p-3 sm:p-4 md:p-6 animate-fade"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.1 }}
        >
          <ScrollReveal>
            <h2 className="section-title mb-3 sm:mb-4 md:mb-5">My Skills</h2>
          </ScrollReveal>

          <StaggerContainer className="space-y-3 sm:space-y-4 px-2 sm:px-3 md:px-5">
            {skills.map((skill, index) => (
              <StaggerItem key={skill.name}>
                <div>
                  <div className="flex items-center gap-1.5 mb-1.5 sm:mb-2">
                    <h5 
                      className="text-xs sm:text-sm font-medium"
                      style={{ color: 'hsl(var(--text-secondary))' }}
                    >
                      {skill.name}
                    </h5>
                    <data 
                      className="text-[11px] sm:text-xs md:text-[13px] font-light"
                      style={{ color: 'hsl(var(--text-muted))' }}
                      value={skill.percentage}
                    >
                      {skill.percentage}%
                    </data>
                  </div>
                  <div className="skill-bar">
                    <motion.div
                      className="skill-bar-fill"
                      initial={{ width: 0 }}
                      whileInView={{ width: `${skill.percentage}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: 0.2 + index * 0.1 }}
                    />
                  </div>
                </div>
              </StaggerItem>
            ))}
          </StaggerContainer>
        </motion.section>
      </div>
    </MainLayout>
  );
};

export default Resume;
