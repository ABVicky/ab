import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { ScrollReveal } from "@/components/animations/ScrollReveal";
import { BlogCard } from "@/components/blog/BlogCard";
import { blogPosts } from "@/data/blogPosts";
import { motion, AnimatePresence } from "framer-motion";
import { DesktopNavbar } from "@/components/layout/Navbar";
import { ChevronDown } from "lucide-react";

const categories = ["All", "Technology", "Psychology", "Leadership", "Experience", "Career"];

const Blog = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [showMobileFilter, setShowMobileFilter] = useState(false);

  const filteredPosts = activeCategory === "All"
    ? blogPosts
    : blogPosts.filter((post) => post.category === activeCategory);

  return (
    <MainLayout>
      <div className="space-y-4 sm:space-y-5 md:space-y-6">
        <motion.section 
          className="card-premium p-3 sm:p-4 md:p-6 animate-fade"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Desktop Navbar - positioned at top-right of this card */}
          <DesktopNavbar />
          
          <ScrollReveal>
            <h1 className="section-title mb-1.5 sm:mb-2">Blog</h1>
            <p className="text-xs sm:text-sm mb-4 sm:mb-5 md:mb-6" style={{ color: 'hsl(var(--text-muted))' }}>
              Thoughts on technology, leadership, and personal growth.
            </p>
          </ScrollReveal>

          {/* Desktop Filter Tabs */}
          <div className="hidden md:flex gap-4 lg:gap-6 mb-6 lg:mb-8 pl-1">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`filter-btn text-xs lg:text-sm capitalize transition-all ${
                  activeCategory === category ? 'active' : ''
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Mobile Filter Select - Original style */}
          <div className="md:hidden relative mb-4 sm:mb-5">
            <button
              onClick={() => setShowMobileFilter(!showMobileFilter)}
              className="w-full flex justify-between items-center px-3 sm:px-4 py-2.5 sm:py-3 rounded-[12px] sm:rounded-[14px] text-xs sm:text-sm"
              style={{ 
                background: 'hsl(var(--card))',
                color: 'hsl(var(--text-muted))',
                border: '1px solid hsl(var(--border))'
              }}
            >
              <span>{activeCategory}</span>
              <motion.div
                animate={{ rotate: showMobileFilter ? 180 : 0 }}
                transition={{ duration: 0.15 }}
              >
                <ChevronDown size={14} className="sm:hidden" />
                <ChevronDown size={16} className="hidden sm:block" />
              </motion.div>
            </button>
            
            <AnimatePresence>
              {showMobileFilter && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute top-full left-0 right-0 mt-1.5 rounded-[12px] sm:rounded-[14px] overflow-hidden z-10"
                  style={{ 
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))'
                  }}
                >
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => {
                        setActiveCategory(category);
                        setShowMobileFilter(false);
                      }}
                      className="w-full text-left px-3 sm:px-4 py-2 text-xs sm:text-sm capitalize hover:bg-secondary/50 transition-colors"
                      style={{ 
                        color: activeCategory === category 
                          ? 'hsl(var(--primary))' 
                          : 'hsl(var(--text-muted))'
                      }}
                    >
                      {category}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Blog Posts Grid */}
          <div className="grid md:grid-cols-2 gap-3 sm:gap-4 md:gap-5">
            {filteredPosts.map((post, index) => (
              <BlogCard key={post.slug} post={post} index={index} />
            ))}
          </div>

          {filteredPosts.length === 0 && (
            <div className="text-center py-8 sm:py-10 md:py-12">
              <p className="text-xs sm:text-sm" style={{ color: 'hsl(var(--text-muted))' }}>No posts found in this category.</p>
            </div>
          )}
        </motion.section>
      </div>
    </MainLayout>
  );
};

export default Blog;
