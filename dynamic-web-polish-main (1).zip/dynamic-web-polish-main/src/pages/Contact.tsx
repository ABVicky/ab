import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { ScrollReveal } from "@/components/animations/ScrollReveal";
import { motion } from "framer-motion";
import { Send, Mail, MapPin, Phone } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import { DesktopNavbar } from "@/components/layout/Navbar";

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1000));

    toast({
      title: "Message sent!",
      description: "Thank you for reaching out. I'll get back to you soon.",
    });

    setFormData({ name: "", email: "", message: "" });
    setIsSubmitting(false);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData((prev) => ({
      ...prev,
      [e.target.name]: e.target.value,
    }));
  };

  return (
    <MainLayout>
      <div className="space-y-4 sm:space-y-5 md:space-y-6">
        <motion.section 
          className="card-premium p-3 sm:p-4 md:p-6 animate-fade"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Desktop Navbar */}
          <DesktopNavbar />
          
          <ScrollReveal>
            <h1 className="section-title mb-4 sm:mb-6 md:mb-8">Contact</h1>
          </ScrollReveal>

          {/* Map Box - Original style */}
          <ScrollReveal delay={0.1}>
            <div 
              className="relative h-[180px] sm:h-[220px] md:h-[300px] lg:h-[380px] w-full rounded-[12px] sm:rounded-[14px] md:rounded-[16px] lg:rounded-[18px] mb-5 sm:mb-6 md:mb-8 overflow-hidden"
              style={{ border: '1px solid hsl(var(--border))' }}
            >
              <figure className="h-full">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d235527.4718266992!2d88.18645975!3d22.5354091!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39f882db4908f667%3A0x43e330e68f6c2cbc!2sKolkata%2C%20West%20Bengal!5e0!3m2!1sen!2sin!4v1706779831812!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 'none', filter: 'grayscale(1) invert(1)' }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                />
              </figure>
            </div>
          </ScrollReveal>

          {/* Contact Form - Original style */}
          <ScrollReveal delay={0.2}>
            <h3 
              className="text-sm sm:text-base md:text-lg font-semibold mb-3 sm:mb-4 md:mb-5"
              style={{ color: 'hsl(var(--text-secondary))' }}
            >
              Contact Form
            </h3>
            
            <form onSubmit={handleSubmit}>
              {/* Input wrapper grid */}
              <div className="grid md:grid-cols-2 gap-3 sm:gap-4 md:gap-5 lg:gap-6 mb-3 sm:mb-4 md:mb-5 lg:mb-6">
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="form-input text-xs sm:text-sm"
                  placeholder="Full Name"
                />
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="form-input text-xs sm:text-sm"
                  placeholder="Email Address"
                />
              </div>

              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                className="form-input text-xs sm:text-sm min-h-[80px] sm:min-h-[90px] md:min-h-[100px] max-h-[150px] sm:max-h-[180px] md:max-h-[200px] resize-y mb-3 sm:mb-4 md:mb-5 lg:mb-6"
                placeholder="Your Message"
              />

              <motion.button
                type="submit"
                disabled={isSubmitting}
                className="form-btn text-xs sm:text-sm w-full md:w-auto md:ml-auto"
                whileHover={{ scale: 1.01 }}
                whileTap={{ scale: 0.99 }}
              >
                <Send size={14} className="sm:hidden" />
                <Send size={16} className="hidden sm:block" />
                {isSubmitting ? "Sending..." : "Send Message"}
              </motion.button>
            </form>
          </ScrollReveal>
        </motion.section>
      </div>
    </MainLayout>
  );
};

export default Contact;
