import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { ScrollReveal, StaggerContainer, StaggerItem } from "@/components/animations/ScrollReveal";
import { motion, AnimatePresence } from "framer-motion";
import { LiftHover } from "@/components/animations/HoverEffects";
import { Eye, ChevronDown } from "lucide-react";
import { DesktopNavbar } from "@/components/layout/Navbar";

const categories = ["All", "Web Development", "Anchoring", "Design"];

const projects = [
  {
    title: "पढ़ाकू (Padhakoo)",
    category: "Web Development",
    description: "EdTech Platform for engineering students",
    image: "https://abvicky.in/assets/images/padhakoo.png",
    tags: ["Web Development", "EdTech Platform"],
  },
  {
    title: "Innov8 Hackathon",
    category: "Anchoring",
    description: "32-hour hackathon event management and hosting",
    image: "https://abvicky.in/assets/images/innov8.png",
    tags: ["Event Management", "Anchoring"],
  },
  {
    title: "League of Errors",
    category: "Anchoring",
    description: "Inter-college coding event with 800+ participants",
    image: "https://abvicky.in/assets/images/league-of-errors.png",
    tags: ["Coding Event", "Anchoring & Operations"],
  },
  {
    title: "BBIT Creatives",
    category: "Design",
    description: "Social media creatives and digital branding",
    image: "https://abvicky.in/assets/images/bbit-designs.png",
    tags: ["Graphic Design", "Social Media"],
  },
  {
    title: "JIMSH Hospital",
    category: "Design",
    description: "Healthcare branding and creative design",
    image: "https://abvicky.in/assets/images/jimsh.png",
    tags: ["Creative Design", "Healthcare Branding"],
  },
  {
    title: "RivuTalks",
    category: "Design",
    description: "Video editing for podcasts and courses",
    image: "https://abvicky.in/assets/images/rivutalks.png",
    tags: ["Video Editing", "Podcasts"],
  },
  {
    title: "Freelance Web Projects",
    category: "Web Development",
    description: "Frontend development for various clients",
    image: "https://abvicky.in/assets/images/freelance-web.png",
    tags: ["Web Development", "Frontend"],
  },
];

const Portfolio = () => {
  const [activeCategory, setActiveCategory] = useState("All");
  const [showMobileFilter, setShowMobileFilter] = useState(false);

  const filteredProjects = activeCategory === "All"
    ? projects
    : projects.filter((p) => p.category === activeCategory);

  return (
    <MainLayout>
      <div className="space-y-4 sm:space-y-5 md:space-y-6">
        <motion.section 
          className="card-premium p-3 sm:p-4 md:p-6 animate-fade"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          {/* Desktop Navbar */}
          <DesktopNavbar />
          
          <ScrollReveal>
            <h1 className="section-title mb-4 sm:mb-5 md:mb-6">Portfolio</h1>
          </ScrollReveal>

          {/* Desktop Filter Tabs */}
          <div className="hidden md:flex gap-4 lg:gap-6 mb-6 lg:mb-8 pl-1">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setActiveCategory(category)}
                className={`filter-btn text-xs lg:text-sm capitalize transition-all ${
                  activeCategory === category ? 'active' : ''
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Mobile Filter Select */}
          <div className="md:hidden relative mb-4 sm:mb-5">
            <button
              onClick={() => setShowMobileFilter(!showMobileFilter)}
              className="w-full flex justify-between items-center px-3 sm:px-4 py-2.5 sm:py-3 rounded-[12px] sm:rounded-[14px] text-xs sm:text-sm"
              style={{ 
                background: 'hsl(var(--card))',
                color: 'hsl(var(--text-muted))',
                border: '1px solid hsl(var(--border))'
              }}
            >
              <span>{activeCategory}</span>
              <motion.div
                animate={{ rotate: showMobileFilter ? 180 : 0 }}
                transition={{ duration: 0.15 }}
              >
                <ChevronDown size={14} className="sm:hidden" />
                <ChevronDown size={16} className="hidden sm:block" />
              </motion.div>
            </button>
            
            <AnimatePresence>
              {showMobileFilter && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.15 }}
                  className="absolute top-full left-0 right-0 mt-1.5 rounded-[12px] sm:rounded-[14px] overflow-hidden z-10"
                  style={{ 
                    background: 'hsl(var(--card))',
                    border: '1px solid hsl(var(--border))'
                  }}
                >
                  {categories.map((category) => (
                    <button
                      key={category}
                      onClick={() => {
                        setActiveCategory(category);
                        setShowMobileFilter(false);
                      }}
                      className="w-full text-left px-3 sm:px-4 py-2 text-xs sm:text-sm capitalize hover:bg-secondary/50 transition-colors"
                      style={{ 
                        color: activeCategory === category 
                          ? 'hsl(var(--primary))' 
                          : 'hsl(var(--text-muted))'
                      }}
                    >
                      {category}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Projects Grid - with scaleUp animation */}
          <AnimatePresence mode="wait">
            <motion.div
              key={activeCategory}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="grid grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-5"
            >
              {filteredProjects.map((project, index) => (
                <motion.div
                  key={project.title}
                  className="animate-scale-up"
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <a href="#" className="block group">
                    {/* Project Image */}
                    <div 
                      className="relative w-full h-[120px] sm:h-[150px] md:h-[180px] lg:h-[200px] rounded-[10px] sm:rounded-[12px] md:rounded-[16px] overflow-hidden mb-2 sm:mb-3 md:mb-4"
                      style={{ boxShadow: 'var(--shadow-2)' }}
                    >
                      {/* Overlay */}
                      <div className="absolute inset-0 bg-transparent group-hover:bg-black/50 transition-all duration-300 z-10" />
                      
                      {/* Eye Icon */}
                      <div 
                        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-2 sm:p-3 md:p-4 rounded-lg md:rounded-xl opacity-0 scale-75 group-hover:opacity-100 group-hover:scale-100 transition-all duration-300 z-20"
                        style={{ 
                          background: 'hsl(var(--border))',
                          color: 'hsl(var(--primary))'
                        }}
                      >
                        <Eye size={16} className="sm:hidden" />
                        <Eye size={18} className="hidden sm:block md:hidden" />
                        <Eye size={20} className="hidden md:block" />
                      </div>
                      
                      <img
                        src={project.image}
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                        loading="lazy"
                      />
                    </div>

                    {/* Content */}
                    <div className="ml-1 sm:ml-1.5 md:ml-2.5">
                      <h3 
                        className="font-normal text-[11px] sm:text-xs md:text-sm capitalize leading-tight mb-0.5 sm:mb-1 transition-colors group-hover:text-primary line-clamp-1"
                        style={{ color: 'hsl(var(--text-secondary))' }}
                      >
                        {project.title}
                      </h3>
                      <p 
                        className="text-[10px] sm:text-xs md:text-sm"
                        style={{ color: 'hsl(var(--text-muted) / 0.7)' }}
                      >
                        {project.category}
                      </p>
                    </div>
                  </a>
                </motion.div>
              ))}
            </motion.div>
          </AnimatePresence>
        </motion.section>
      </div>
    </MainLayout>
  );
};

export default Portfolio;
