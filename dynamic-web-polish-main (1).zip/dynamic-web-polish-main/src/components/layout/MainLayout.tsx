import { ReactNode } from "react";
import { MobileNavbar } from "./Navbar";
import { ProfileSidebar } from "./ProfileSidebar";
import { PageTransition } from "../animations/PageTransition";

interface MainLayoutProps {
  children: ReactNode;
  showSidebar?: boolean;
}

export const MainLayout = ({ children, showSidebar = true }: MainLayoutProps) => {
  return (
    <PageTransition>
      <div className="min-h-screen bg-background">
        {/* Mobile/Tablet bottom navbar */}
        <MobileNavbar />
        
        <main className="pt-3 sm:pt-4 md:pt-6 lg:pt-8 pb-16 sm:pb-18 md:pb-20 lg:pb-16 px-2.5 sm:px-4 md:px-6 lg:px-8 max-w-7xl mx-auto">
          <div className={`flex flex-col ${showSidebar ? 'lg:flex-row' : ''} gap-3 sm:gap-4 md:gap-5 lg:gap-6`}>
            {/* Sidebar */}
            {showSidebar && (
              <aside className="lg:w-72 xl:w-80 lg:flex-shrink-0">
                <div className="lg:sticky lg:top-6">
                  <ProfileSidebar />
                </div>
              </aside>
            )}

            {/* Main Content Area */}
            <div className="flex-1 min-w-0">
              {children}
            </div>
          </div>
        </main>
      </div>
    </PageTransition>
  );
};
