import { motion } from "framer-motion";
import { Mail, MapPin, Calendar, Linkedin, Github, Instagram, ChevronDown } from "lucide-react";
import { ScaleReveal } from "../animations/ScrollReveal";
import { useState, useEffect, memo } from "react";

// Role text animation - Original abvicky.site feature
const roles = [
  "Web Developer",
  "Debater",
  "Entrepreneur",
  "Community Builder",
  "Technical Mentor",
  "Digital Marketer",
  "Hackathon Organizer",
  "Problem Solver"
];

const socialLinks = [
  { icon: Linkedin, href: "https://linkedin.com/in/abvicky", label: "LinkedIn" },
  { icon: Github, href: "https://github.com/abvicky", label: "GitHub" },
  { icon: Instagram, href: "https://instagram.com/ab.vicky_", label: "Instagram" },
];

const contactInfo = [
  { icon: Mail, label: "Email", value: "vickyprasadmahato@gmail.com" },
  { icon: Calendar, label: "Birthday", value: "Nov, 2004" },
  { icon: MapPin, label: "Location", value: "Kolkata - WB, India" },
];

// Extracted role badge component - only this re-renders on role change
const RoleBadge = memo(({ roleIndex, isFadingOut, isMobile }: { roleIndex: number; isFadingOut: boolean; isMobile?: boolean }) => (
  <span 
    className={`${isMobile ? 'inline-block text-[11px] font-light px-3 py-1 rounded-lg' : 'badge-premium text-xs'} ${
      isFadingOut ? 'role-text-fade-out' : 'role-text-fade-in'
    }`}
    style={isMobile ? { 
      background: 'hsl(var(--muted))',
      color: 'hsl(var(--text-primary))'
    } : undefined}
  >
    {roles[roleIndex]}
  </span>
));

RoleBadge.displayName = 'RoleBadge';

// Mobile compact layout - memoized to prevent unnecessary re-renders
const MobileProfile = memo(({ isExpanded, setIsExpanded, roleIndex, isFadingOut }: {
  isExpanded: boolean;
  setIsExpanded: (val: boolean) => void;
  roleIndex: number;
  isFadingOut: boolean;
}) => (
  <div className="lg:hidden">
    <motion.aside
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
      className={`sidebar-mobile bg-card rounded-[16px] sm:rounded-[20px] border border-border overflow-hidden transition-all duration-500 ${
        isExpanded ? 'max-h-[360px] sm:max-h-[380px]' : 'max-h-[90px] sm:max-h-[100px]'
      }`}
      style={{ boxShadow: 'var(--shadow-1)' }}
    >
      {/* Sidebar Info - Avatar, Name, Title, Toggle Button */}
      <div className="sidebar-info relative flex items-center gap-3 sm:gap-4">
        {/* Avatar */}
        <a href="#" className="flex-shrink-0">
          <figure className="avatar-box-mobile">
            <img
              src="https://abvicky.github.io/Portfolio/Images/Profile_Photo.jpg"
              alt="Vicky Prasad Mahato"
              className="w-14 sm:w-16 md:w-20 rounded-[16px] sm:rounded-[20px] object-cover"
              loading="lazy"
            />
          </figure>
        </a>
        
        {/* Name and Title */}
        <div className="info-content flex-1 min-w-0">
          <h1 className="text-sm sm:text-base md:text-lg font-medium tracking-tight mb-1.5 sm:mb-2" style={{ color: 'hsl(var(--text-secondary))' }}>
            Vicky Prasad Mahato
          </h1>
          <RoleBadge roleIndex={roleIndex} isFadingOut={isFadingOut} isMobile />
        </div>

        {/* Show Contacts Button - Top Right Corner - Original style */}
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="absolute -top-[12px] sm:-top-[15px] -right-[12px] sm:-right-[15px] rounded-bl-[12px] sm:rounded-bl-[15px] rounded-tr-[16px] sm:rounded-tr-[20px] text-[12px] sm:text-[13px] p-2 sm:p-2.5 z-10 transition-all"
          style={{
            background: 'var(--border-gradient-onyx)',
            color: 'hsl(var(--primary))',
            boxShadow: 'var(--shadow-2)'
          }}
        >
          <span className="hidden">Show Contacts</span>
          <motion.div
            animate={{ rotate: isExpanded ? 180 : 0 }}
            transition={{ duration: 0.3 }}
          >
            <ChevronDown size={14} className="sm:hidden" />
            <ChevronDown size={16} className="hidden sm:block" />
          </motion.div>
        </button>
      </div>

      {/* Expandable Info Section */}
      <div className={`sidebar-info_more transition-all duration-500 ${isExpanded ? 'opacity-100 visible' : 'opacity-0 invisible'}`}>
        {/* Separator */}
        <div className="separator" />

        {/* Contact List */}
        <ul className="contacts-list grid grid-cols-1 gap-3 sm:gap-4">
          {contactInfo.map((item) => (
            <li key={item.label} className="contact-item flex items-center gap-3 sm:gap-4">
              <div className="icon-box w-7 h-7 sm:w-8 sm:h-8">
                <item.icon size={14} className="sm:hidden" />
                <item.icon size={16} className="hidden sm:block" />
              </div>
              <div className="contact-info min-w-0 flex-1">
                <p className="text-[10px] sm:text-[11px] uppercase mb-0.5" style={{ color: 'hsl(var(--text-muted) / 0.7)' }}>
                  {item.label}
                </p>
                <p className="text-[11px] sm:text-[12px] md:text-[13px]" style={{ color: 'hsl(var(--text-secondary))' }}>
                  {item.value}
                </p>
              </div>
            </li>
          ))}
        </ul>

        {/* Separator */}
        <div className="separator" />

        {/* Social Links */}
        <ul className="social-list flex items-center gap-3 sm:gap-4 pl-2 pb-1">
          {socialLinks.map((social) => (
            <li key={social.label} className="social-item">
              <a
                href={social.href}
                target="_blank"
                rel="noopener noreferrer"
                className="text-base sm:text-lg transition-colors"
                style={{ color: 'hsl(var(--text-muted) / 0.7)' }}
                aria-label={social.label}
              >
                <social.icon size={16} className="sm:hidden" />
                <social.icon size={18} className="hidden sm:block" />
              </a>
            </li>
          ))}
        </ul>
      </div>
    </motion.aside>
  </div>
));

MobileProfile.displayName = 'MobileProfile';

// Desktop sidebar layout - memoized (only shows on lg and up)
const DesktopProfile = memo(({ roleIndex, isFadingOut }: { roleIndex: number; isFadingOut: boolean }) => (
  <div className="hidden lg:block">
    <ScaleReveal>
      <div className="profile-sidebar">
        {/* Avatar */}
        <div className="mb-4 lg:mb-6">
          <img
            src="https://abvicky.github.io/Portfolio/Images/Profile_Photo.jpg"
            alt="Vicky Prasad Mahato"
            className="avatar-premium"
            loading="lazy"
          />
        </div>

        {/* Name */}
        <h2
          className="text-base lg:text-lg font-medium mb-2"
          style={{ color: 'hsl(var(--text-secondary))' }}
        >
          Vicky Prasad Mahato
        </h2>

        {/* Title Badge - with role animation */}
        <div className="mb-4 lg:mb-6">
          <RoleBadge roleIndex={roleIndex} isFadingOut={isFadingOut} />
        </div>

        {/* Divider */}
        <div className="separator" />

        {/* Contact Info */}
        <div className="flex flex-col gap-3 lg:gap-4 text-left">
          {contactInfo.map((item) => (
            <div
              key={item.label}
              className="flex items-center gap-2.5 lg:gap-3"
            >
              <div className="icon-box w-10 h-10 lg:w-12 lg:h-12">
                <item.icon size={16} className="lg:hidden" />
                <item.icon size={18} className="hidden lg:block" />
              </div>
              <div>
                <p className="text-[10px] lg:text-[11px] uppercase tracking-wider" style={{ color: 'hsl(var(--text-muted) / 0.7)' }}>
                  {item.label}
                </p>
                <p className="text-[12px] lg:text-[13px] truncate max-w-[130px] lg:max-w-[150px]" style={{ color: 'hsl(var(--text-secondary))' }}>
                  {item.value}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Divider */}
        <div className="separator my-4 lg:my-6" />

        {/* Social Links */}
        <div className="flex items-center justify-center gap-3 lg:gap-4">
          {socialLinks.map((social) => (
            <a
              key={social.label}
              href={social.href}
              target="_blank"
              rel="noopener noreferrer"
              className="social-icon w-9 h-9 lg:w-10 lg:h-10"
              aria-label={social.label}
            >
              <social.icon size={16} className="lg:hidden" />
              <social.icon size={18} className="hidden lg:block" />
            </a>
          ))}
        </div>
      </div>
    </ScaleReveal>
  </div>
));

DesktopProfile.displayName = 'DesktopProfile';

export const ProfileSidebar = () => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [roleIndex, setRoleIndex] = useState(0);
  const [isFadingOut, setIsFadingOut] = useState(false);

  // Role text animation interval
  useEffect(() => {
    const interval = setInterval(() => {
      setIsFadingOut(true);
      
      setTimeout(() => {
        setRoleIndex((prev) => (prev + 1) % roles.length);
        setIsFadingOut(false);
      }, 400);
    }, 2500);

    return () => clearInterval(interval);
  }, []);

  return (
    <>
      <MobileProfile 
        isExpanded={isExpanded} 
        setIsExpanded={setIsExpanded}
        roleIndex={roleIndex}
        isFadingOut={isFadingOut}
      />
      <DesktopProfile roleIndex={roleIndex} isFadingOut={isFadingOut} />
    </>
  );
};
