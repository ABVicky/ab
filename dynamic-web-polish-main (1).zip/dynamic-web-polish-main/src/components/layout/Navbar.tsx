import { memo } from "react";
import { Link, useLocation } from "react-router-dom";
import { motion } from "framer-motion";

const navItems = [
  { name: "About", path: "/" },
  { name: "Resume", path: "/resume" },
  { name: "Portfolio", path: "/portfolio" },
  { name: "Blog", path: "/blog" },
  { name: "Contact", path: "/contact" },
];

// Desktop navbar component to be placed inside card-premium
export const DesktopNavbar = () => {
  const location = useLocation();

  return (
    <motion.nav
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5, delay: 0.2 }}
      className="navbar-desktop"
    >
      <ul className="navbar-list flex items-center gap-8 px-5">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path || 
            (item.path === "/blog" && location.pathname.startsWith("/blog"));
          return (
            <li key={item.name} className="navbar-item">
              <Link
                to={item.path}
                className={`navbar-link text-[13px] font-medium py-5 block transition-colors ${
                  isActive 
                    ? "text-primary" 
                    : "text-muted-foreground hover:text-muted-foreground/70"
                }`}
              >
                {item.name}
              </Link>
            </li>
          );
        })}
      </ul>
    </motion.nav>
  );
};

// Mobile bottom navbar - Optimized with memo
export const MobileNavbar = memo(() => {
  const location = useLocation();

  return (
    <nav className="navbar-mobile">
      <ul className="navbar-list">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path ||
            (item.path === "/blog" && location.pathname.startsWith("/blog"));
          return (
            <li key={item.name} className="navbar-item">
              <Link
                to={item.path}
                className={`navbar-link ${isActive ? "active" : ""}`}
              >
                {item.name}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
});

// Combined navbar component for backward compatibility
export const Navbar = () => {
  return (
    <>
      <div className="hidden md:block">
        <DesktopNavbar />
      </div>
      <div className="md:hidden">
        <MobileNavbar />
      </div>
    </>
  );
};
