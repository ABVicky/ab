import { motion, HTMLMotionProps } from "framer-motion";
import { ReactNode } from "react";

// Scale on hover
interface ScaleHoverProps extends HTMLMotionProps<"div"> {
  children: ReactNode;
  scale?: number;
  className?: string;
}

export const ScaleHover = ({ 
  children, 
  scale = 1.02, 
  className = "",
  ...props 
}: ScaleHoverProps) => {
  return (
    <motion.div
      whileHover={{ scale }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      className={className}
      {...props}
    >
      {children}
    </motion.div>
  );
};

// Lift on hover (with shadow)
export const LiftHover = ({ 
  children, 
  className = "" 
}: { 
  children: ReactNode; 
  className?: string 
}) => {
  return (
    <motion.div
      whileHover={{ 
        y: -4,
        boxShadow: "0 8px 30px hsla(45, 80%, 60%, 0.15)"
      }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// Glow on hover
export const GlowHover = ({ 
  children, 
  className = "" 
}: { 
  children: ReactNode; 
  className?: string 
}) => {
  return (
    <motion.div
      whileHover={{ 
        boxShadow: "0 0 30px hsla(45, 80%, 60%, 0.3)"
      }}
      transition={{ duration: 0.3 }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

// Button hover animation
export const ButtonHover = ({ 
  children, 
  className = "",
  onClick
}: { 
  children: ReactNode; 
  className?: string;
  onClick?: () => void;
}) => {
  return (
    <motion.button
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      transition={{ type: "spring", stiffness: 400, damping: 17 }}
      className={className}
      onClick={onClick}
    >
      {children}
    </motion.button>
  );
};

// Card tilt effect
export const TiltCard = ({ 
  children, 
  className = "" 
}: { 
  children: ReactNode; 
  className?: string 
}) => {
  return (
    <motion.div
      whileHover={{ 
        rotateX: 2,
        rotateY: 2,
        scale: 1.02
      }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      className={className}
      style={{ transformStyle: "preserve-3d" }}
    >
      {children}
    </motion.div>
  );
};

// Icon bounce on hover
export const IconBounce = ({ 
  children, 
  className = "" 
}: { 
  children: ReactNode; 
  className?: string 
}) => {
  return (
    <motion.div
      whileHover={{ 
        y: -3,
        transition: {
          y: {
            repeat: Infinity,
            repeatType: "reverse",
            duration: 0.3
          }
        }
      }}
      className={className}
    >
      {children}
    </motion.div>
  );
};
