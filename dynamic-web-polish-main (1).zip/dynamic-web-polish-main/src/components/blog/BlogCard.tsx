import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Calendar, Clock, ArrowRight } from "lucide-react";
import { BlogPost } from "@/data/blogPosts";
import { LiftHover } from "../animations/HoverEffects";

interface BlogCardProps {
  post: BlogPost;
  index?: number;
}

export const BlogCard = ({ post, index = 0 }: BlogCardProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
    >
      <LiftHover>
        <Link to={`/blog/${post.slug}`} className="block blog-card h-full">
          {/* Image */}
          <div className="relative overflow-hidden">
            <img
              src={post.featuredImage}
              alt={post.title}
              className="blog-card-image"
              loading="lazy"
            />
            <div className="absolute top-2 sm:top-3 md:top-4 left-2 sm:left-3 md:left-4">
              <span className="badge-premium text-[10px] sm:text-xs">{post.category}</span>
            </div>
          </div>

          {/* Content */}
          <div className="p-3 sm:p-4 md:p-5 lg:p-6">
            {/* Meta */}
            <div className="flex items-center gap-2 sm:gap-3 md:gap-4 text-[10px] sm:text-xs md:text-sm text-muted-foreground mb-1.5 sm:mb-2 md:mb-3">
              <span className="flex items-center gap-1 sm:gap-1.5">
                <Calendar size={12} className="sm:hidden" />
                <Calendar size={14} className="hidden sm:block" />
                {post.publishDate}
              </span>
              <span className="flex items-center gap-1 sm:gap-1.5">
                <Clock size={12} className="sm:hidden" />
                <Clock size={14} className="hidden sm:block" />
                {post.readTime}
              </span>
            </div>

            {/* Title */}
            <h3 className="text-sm sm:text-base md:text-lg font-semibold text-foreground mb-1 sm:mb-1.5 md:mb-2 line-clamp-2 group-hover:text-primary transition-colors">
              {post.title}
            </h3>

            {/* Excerpt */}
            <p className="text-muted-foreground text-[11px] sm:text-xs md:text-sm line-clamp-2 mb-2 sm:mb-3 md:mb-4">
              {post.excerpt}
            </p>

            {/* Read More */}
            <div className="flex items-center gap-1.5 sm:gap-2 text-primary text-[11px] sm:text-xs md:text-sm font-medium group">
              <span>Read More</span>
              <ArrowRight size={12} className="sm:hidden transition-transform group-hover:translate-x-1" />
              <ArrowRight size={14} className="hidden sm:block md:hidden transition-transform group-hover:translate-x-1" />
              <ArrowRight size={16} className="hidden md:block transition-transform group-hover:translate-x-1" />
            </div>
          </div>
        </Link>
      </LiftHover>
    </motion.div>
  );
};
